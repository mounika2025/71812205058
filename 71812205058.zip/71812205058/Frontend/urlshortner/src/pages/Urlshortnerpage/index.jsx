import React from 'react'

const index = () => {
  return (
    <> 
    <div className="flex flex-col  min-h-screen mt-10 items-center">
      <div className=" p-8 rounded-2xl shadow-lg w-full max-w-md text-center ">
        <span className="block text-lg font-semibold text-gray-800 mb-4">
          Paste your URL here
        </span>
        <input type="text" id="urllink" placeholder="Enter your URL" className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg  mb-4"/>
        <input type='number' className='w-full px-4 py-2 border-2 border-gray-300 rounded-lg  mb-4' placeholder='enter Validity'></input>
        <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-lg">
          Shorten
        </button>
      </div>
    </div>
    <div>
        <p></p>
    </div>
    </>
  )
}

export default index
