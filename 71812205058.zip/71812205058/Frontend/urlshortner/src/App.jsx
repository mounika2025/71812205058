import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import Urlshortner from './pages/Urlshortnerpage/index';
import StatisticsPage from './pages/StatisticsPage/index';

const App = () => {
  return (
    <Router>
      <div className='bg-blue-900'>
        <nav className="flex items-center justify-between px-8 py-4">
          <div className="flex gap-6">
            <NavLink to="/"  className={({ isActive }) => 
        `text-lg font-medium ${isActive ? "text-black border-b-2 border-yellow-400" : "text-blue-600 font-bold"}`
              }>
        UrlShortner
            </NavLink>
            <NavLink to="/StatisticsPage" className={({ isActive }) => 
                `text-lg font-medium ${isActive ? "text-black border-b-2 border-yellow-400" : "text-blue-600 font-bold"}`
              }>
              Statistics Page
            </NavLink>
          </div>
        </nav>
      </div>

      <Routes>
        <Route path="/" element={<Urlshortner />} />
        <Route path="/StatisticsPage" element={<StatisticsPage />} />
      </Routes>
    </Router>
  )
}

export default App;
